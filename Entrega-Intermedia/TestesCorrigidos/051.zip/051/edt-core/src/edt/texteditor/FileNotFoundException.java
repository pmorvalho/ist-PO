package edt.texteditor;

public class FileNotFoundException extends Exception {}